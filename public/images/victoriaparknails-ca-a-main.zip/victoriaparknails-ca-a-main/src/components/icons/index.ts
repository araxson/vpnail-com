export { TikTokIcon } from "./tiktok-icon";
